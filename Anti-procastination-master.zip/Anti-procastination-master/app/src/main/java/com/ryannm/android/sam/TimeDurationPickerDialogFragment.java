package com.ryannm.android.sam;

import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;

public class TimeDurationPickerDialogFragment extends DialogFragment {
    public static final String TAG = "TimeDurationPicker";
    /*private TimeDurationPickerDialog.OnDurationSetListener mCallback;

    @Override @NonNull
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return new TimeDurationPickerDialog(getActivity(), mCallback, 0);
    }

    public TimeDurationPickerDialogFragment onTimeSet (TimeDurationPickerDialog.OnDurationSetListener callback) {
        mCallback = callback;
        return this;
    } */
}
